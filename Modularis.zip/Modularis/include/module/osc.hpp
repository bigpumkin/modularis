#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp> 
#include <cmath>
#include  "basic.hpp"

class Oscillator : public Basic
{
  public:
	Oscillator();
};

